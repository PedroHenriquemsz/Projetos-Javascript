let url = 'dados/xmlresult10.xml'
const _cep = 'https://viacep.com.br/ws/${cep}/json/'
$.ajax(url, _cep)
    .done(function(xml,json){
         $(xml,json).find("aluno",).each(function(){
          let nome =  $(this).find("nome").text()
          let cep =  $(this).find("cep").text().slice(0,8)
          let email = $(this).find("email").text().trim()
          let erro = $(this).find("error").text()
          

          
            $("#cards").append(`<div class="card">
            <p class="nome"> ${nome} </p>
            <p class="cep"> ${cep} </p>
            <p class="email"> ${email} </p>
            <a class="linkcep" href="https://viacep.com.br/ws/${cep}/json/">Clique aqui</a>
            <br>
            <br>
            </div>
            `)
            
        })
       
    })
    .fail(function(){
        alert("Ocorreu um erro na leitura do arquivo")

    })

    if(erro == true){
              document.getElementsByClassName("card").style.backgroundColor = "red"

          }
    
    /* Possivel modo de alterar dados do email(tirar espaços em branco)
    xmlDoc=loadXMLDoc("xmlresult17.xml");
email=xmlDoc.getElementsByTagName("email")[0].childNodes[0];
x.nodeValue.trim();
document.write(email.nodeValue);
Obs: não está funcionando no momento*/ 
    

    