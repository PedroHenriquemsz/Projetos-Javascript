let url = 'dados/xmlresult17.xml'
//let urlStr = "https://viacep.com.br/ws/"+ dados +"/json/"

$.ajax(url)
    .done(function(xml){
        $(xml).find("aluno","responsavel").each(function(){
          let nome =  $(this).find("nome").text()
          let cep =  $(this).find("cep").text().slice(0,7)
          let email = $(this).find("email").text().trim()

            $("#cards").append(`<div class="card">
            <p class="nome"> ${nome} </p>
            <p class="cep"> ${cep} </p>
            <p class="email"> ${email} </p>
            <br>
            <br>
            </div>
            `)
        })
       
    })
    .fail(function(){
        alert("Ocorreu um erro na leitura do arquivo")

    })


    /* Possivel modo de alterar dados do email(tirar espaços em branco)
    xmlDoc=loadXMLDoc("xmlresult17.xml");
email=xmlDoc.getElementsByTagName("email")[0].childNodes[0];
x.nodeValue.trim();

document.write(email.nodeValue);
Obs: não está funcionando no momento*/ 
    

    